%--------------------------------------------------------------------------
% Developed in MATLAB R2016a
% The code is based on the following papers.
% A. Naik,S.C. Satapathy,Past present future: a new human-based algorithm for stochastic optimization.
% Soft Comput 25, 12915�12976 (2021). https://doi.org/10.1007/s00500-021-06229-8 
%--------------------------------------------------------------------------
function [Leader_score,Leader_pos,Convergence_curve]=PPF(N,M,S,Max_iter,lb,ub,dim,fobj)
%Initialize the position of populations
P=initialization(N,dim,ub,lb);
presentP = P;
pastP = P;
futureP=P;
Convergence_curve=zeros(1,Max_iter);
f=zeros(N, 1);
% initialize position vector and score for the leader
Leader_pos=zeros(1,dim);
Leader_score=inf; %change this to -inf for maximization problems

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculate objective function for each population 
for i=1:size(P,1)
	f(i,1)=fobj(P(i,:));
        
	%Update the leader
    if f(i,1)<Leader_score % Change this to > for maximization problem
        Leader_score=f(i,1); 
        Leader_pos=P(i,:);
    end        
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
presentF = f;
pastF = f;
futureF=f;

%%%%%%%% Division of population into the subgroup and finding SGbest person
%%%%%%%% of each subgroup %%%%%%%%%%%%%%%%%%%%
SGbestInd=zeros(S,1);    %Indices of SGbests 
SGbest = zeros(S,dim);  %Positions of SGbests
for p = 1:S
	SI = (p-1) * M + 1;
	EI = SI + M - 1;
	[~,leadIndex]=min(f(SI:EI)); 
	SGbestInd(p,1) = (SI - 1) + leadIndex; %Index of SGbest
    SGbest(p,:) = P(SGbestInd(p,1),:);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Convergence_curve(1)=Leader_score;

t=1;% Loop counter
while t<Max_iter
    pastF = presentF;
    pastP = presentP;
    presentF = futureF;
    presentP = futureP;

    
%%%%%%%%%%%%%%%%%%%%% For future updating of population %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    for a = 1:M
        for p = 1:S
            i = (p-1)*M + a; %index of member
            for j=1:dim
                %position-updating w.r.t subgroup best member
                 SGD = SGbest(p,j);
               
                %if present work is improved
                if pastF(i) >= presentF(i) 
                    if (pastP(i,j) <= presentP(i,j) && presentP(i,j) <= SGD) ...
                            || (pastP(i,j) >= presentP(i,j) && presentP(i,j) >= SGD)
                    
                             futureP(i,j) = SGD + (2*rand()-1) * abs(SGD - presentP(i,j));
                    elseif (pastP(i,j) <= presentP(i,j) && presentP(i,j) >= SGD && SGD >= pastP(i,j)) ...
                            || (pastP(i,j) >= presentP(i,j) && presentP(i,j) <= SGD && SGD <= pastP(i,j))
                                           
                             futureP(i,j) =SGD + (2*rand()-1) * abs(presentP(i,j) - SGD);
                    elseif (pastP(i,j) <= presentP(i,j) && presentP(i,j) >= SGD && SGD <= pastP(i,j)) ...
                            || (pastP(i,j) >= presentP(i,j) && presentP(i,j) <= SGD && SGD >= pastP(i,j))
                    
                             futureP(i,j) = SGD + (2*rand()-1) * abs(pastP(i,j) - SGD);
                    end
                
                % if present work is deteriorated
                elseif pastF(i) < presentF(i) 
                    if (pastP(i,j) <= presentP(i,j) && presentP(i,j) <= SGD) ...
                            || (pastP(i,j) >= presentP(i,j) && presentP(i,j) >= SGD)
                    
                        futureP(i,j) = SGD + (2*rand()-1) * abs(presentP(i,j) - SGD);
                    elseif (pastP(i,j) <= presentP(i,j) && presentP(i,j) >= SGD && SGD >= pastP(i,j)) ...
                            || (pastP(i,j) >= presentP(i,j) && presentP(i,j) <= SGD && SGD <= pastP(i,j))
                
                        futureP(i,j) = pastP(i,j) + (2*rand()-1) * abs(presentP(i,j) - pastP(i,j));
                    elseif (pastP(i,j) <= presentP(i,j) && presentP(i,j) >= SGD && SGD <= pastP(i,j)) ...
                            || (pastP(i,j) >= presentP(i,j) && presentP(i,j) <= SGD && SGD >= pastP(i,j))
            
                        futureP(i,j) = SGD + (2*rand()-1) * abs(SGD - pastP(i,j));
                    end
                end
            
            end
        end
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% Subgroup switching Phase %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for p=1:S
    for a=1:M
        fromSet = (p-1)*M + a;
           %Selecting a subgroup other than current where want to send the
            %member
            toS = randi(S);
            while(toS == p)
                toS = randi(S);
            end
            
            %Deciding member in TO subgroup
             toSI = (toS-1) * M + 1;
             toSE = toSI + M - 1;
             [~,toSLeastFit] = max(futureF(toSI:toSE));
             toSet = toSI + toSLeastFit-1;
            
            %Deciding what to do with member in FROM subgroup and switching
            fromSet = (p-1)*M + a;
            temp = futureP(toSet,:);
            futureP(toSet,:) = futureP(fromSet);
            futureP(fromSet,:)=temp;
                
            temp = futureF(toSet);
            futureF(toSet) = futureF(fromSet);
            futureF(fromSet) = temp;
     end
end

%%%%%%%%%%%%%%%%% updating the future position of the population %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:size(P,1)
	% Return back the person that go beyond the boundaries of the search space
 	Flag4ub=futureP(i,:)>ub;
 	Flag4lb=futureP(i,:)<lb;
 	futureP(i,:)=(futureP(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
       
	%Calculate objective function for each person
	futureF(i,1)=fobj(futureP(i,:));
        
	%Update the leader
    if futureF(i,1)<Leader_score % Change this to > for maximization problem
        Leader_score=futureF(i,1); 
        Leader_pos=futureP(i,:);
    end        
end
%%%%%%%%%%%%%%%%%%%%% Finding SGbest person of the subgroup %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

SGbestInd=zeros(S,1);   %Indices of SGbest
SGbest = zeros(S,dim);  %Positions of SGbest
for p = 1:S
	SI = (p-1) * M + 1;
	EI = SI + M- 1;
	[~,leadIndex]=min(futureF(SI:EI)); 
	SGbestInd(p,1) = (SI - 1) + leadIndex; %Index of SGbest
    SGbest(p,:) = futureP(SGbestInd(p,1),:);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    t=t+1;
    Convergence_curve(t)=Leader_score;
  
end
end

