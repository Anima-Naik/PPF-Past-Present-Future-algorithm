%--------------------------------------------------------------------------
% Developed in MATLAB R2016a
% The code is based on the following papers.
% A. Naik,S.C. Satapathy,Past present future: a new human-based algorithm for stochastic optimization.
% Soft Comput 25, 12915�12976 (2021). https://doi.org/10.1007/s00500-021-06229-8 
%--------------------------------------------------------------------------
clear all 
close all
clc
format short
format compact

SearchAgents_no=50; % Number of search agents
Max_iteration=200;

fname='F1'
[lb,ub,dim,fobj] = Get_Functions_details(fname);

con=30; %number of different run
for co=1:con
 S=5;
 M=10;
[Best_score,Best_pos,PPF_curve]=PPF(SearchAgents_no,S,M,Max_iteration,lb,ub,dim,fobj);
value(co)=Best_score;
end
fitness=sort(value,'ascend');

for i=1:30
    PPFfit(i)=fitness(i);
end
best=PPFfit(1)
worse=PPFfit(30)
average=mean(PPFfit)
stdvalue=std(PPFfit)

 
