%--------------------------------------------------------------------------
% Developed in MATLAB R2016a
% The code is based on the following papers.
% A. Naik,S.C. Satapathy,Past present future: a new human-based algorithm for stochastic optimization.
% Soft Comput 25, 12915�12976 (2021). https://doi.org/10.1007/s00500-021-06229-8 
%--------------------------------------------------------------------------

% This function initialize the first population of search agents
function Positions=initialization(SearchAgents_no,dim,ub,lb)

Boundary_no= size(ub,2); % numnber of boundaries

% If the boundaries of all variables are equal and user enter a signle % number for both ub and lb
if Boundary_no==1
    Positions=rand(SearchAgents_no,dim).*(ub-lb)+lb;
end

% If each variable has a different lb and ub
if Boundary_no>1
    for i=1:dim
        ub_i=ub(i);
        lb_i=lb(i);
        Positions(:,i)=rand(SearchAgents_no,1).*(ub_i-lb_i)+lb_i;
    end
end